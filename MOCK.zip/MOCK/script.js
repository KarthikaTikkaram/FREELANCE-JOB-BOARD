document.addEventListener('DOMContentLoaded', function() {
    const jobPostForm = document.getElementById('jobPostForm');

    if (jobPostForm) {
        jobPostForm.addEventListener('submit', function(event) {
            event.preventDefault();

            const jobTitle = document.getElementById('jobTitle').value;
            const jobDescription = document.getElementById('jobDescription').value;
            const jobSkills = document.getElementById('jobSkills').value;
            const jobBudget = document.getElementById('jobBudget').value;

            // Validate inputs (can be enhanced further)
            if (!jobTitle || !jobDescription || !jobSkills || !jobBudget) {
                alert('Please fill in all fields.');
                return;
            }

            // Post job data to server (mocked as console log)
            console.log('Job Posted:', { jobTitle, jobDescription, jobSkills, jobBudget });
            alert('Job posted successfully!');
            jobPostForm.reset(); // Clear form
        });
    }

    // Dummy data for job listings (can be fetched from server in real scenario)
    const jobsData = [
        { id: 1, title: 'Web Developer Needed', description: 'Looking for an experienced web developer to create a company website.', skills: 'HTML, CSS, JavaScript', budget: 1000 },
        { id: 2, title: 'Graphic Designer for Logo Design', description: 'Need a creative graphic designer to design a logo for our startup.', skills: 'Adobe Illustrator, Adobe Photoshop', budget: 500 },
        { id: 3, title: 'Content Writer for Blog Posts', description: 'Seeking a content writer to write engaging blog posts on technology topics.', skills: 'SEO, Blogging', budget: 300 }
    ];

    const jobListings = document.getElementById('jobListings');

    if (jobListings) {
        displayJobs(jobsData); // Display jobs on page load (can be filtered/searched)
    }

    // Function to display job listings
    function displayJobs(jobs) {
        jobListings.innerHTML = ''; // Clear previous listings

        jobs.forEach(job => {
            const jobCard = document.createElement('div');
            jobCard.classList.add('job-card');
            jobCard.innerHTML = `
                <h2>${job.title}</h2>
                <p><strong>Description:</strong> ${job.description}</p>
                <p><strong>Skills Required:</strong> ${job.skills}</p>
                <p><strong>Budget:</strong> $${job.budget}</p>
                <button onclick="applyJob(${job.id})">Apply</button>
            `;
            jobListings.appendChild(jobCard);
        });
    }

    // Function to simulate applying for a job (can be extended with actual functionality)
    function applyJob(jobId) {
        const freelancerName = prompt('Enter your name:');
        const freelancerEmail = prompt('Enter your email:');
        const applicationText = prompt('Enter your application text:');

        if (!freelancerName || !freelancerEmail || !applicationText) {
            alert('Please fill in all fields.');
            return;
        }

        // Simulate application (can be replaced with actual API call)
        console.log(`Applied for job with ID ${jobId}:`, { freelancerName, freelancerEmail, applicationText });
        alert('Application submitted successfully!');
    }
});
